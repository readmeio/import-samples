---
title: "other page"
excerpt: "this is the other page"
---
This is the other page
